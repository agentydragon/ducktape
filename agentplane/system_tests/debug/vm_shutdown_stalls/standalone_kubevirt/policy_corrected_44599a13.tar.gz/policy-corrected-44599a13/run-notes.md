# Policy-corrected standalone VMI run

- BuildBuddy invocation: `44599a13-f3f4-47c8-ab2f-3fc2a2048595` (passed).
- Target: `//agentplane/system_tests/vm:test_tcg_vmi_shutdown`.
- Base checkout revision: `9b5b98113f010a60b04a9c7199608dc6d3edf88a`.
- Exact test source SHA-256: `01911c0b3d61abeb59b2acb25b4ea0d689a706a1ed2b3367b694ee8e38c1f19b`.
- Test source and the complete relevant pre-repeat source patch are retained beside the BuildBuddy undeclared outputs; `SHA256SUMS` covers all downloaded files.
- The output records four guest ACPI shutdown request markers and QMP `query-kvm` as `enabled:false`.
- The scoped production-derived ClusterPolicy was admitted: `virtiofs-state` appeared as an initContainer with restart policy `Always`.
- The 2-second lifecycle observer sampled that same launcher Pod UID and saw `virtiofs-state` running after VMI deletion began; the Pod was absent at 00:06:23.911559Z, about 11.2 seconds after the request. It did not sample a terminated `finishedAt` for that container.
- Kubernetes `deletionTimestamp` was `00:07:12Z`, later than the observer's UTC sample timestamps. Treat the raw timestamp as the scheduled deletion/grace deadline field, not as deletion initiation; the event order comes from observer `observed_at_utc`, not that field.
- This direct VMI run remains distinct from Agentplane Sandbox/controller topology.
